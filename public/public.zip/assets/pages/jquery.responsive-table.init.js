/**
 * Theme: Metrica - Responsive Bootstrap 4 Admin Dashboard
 * Author: Mannatthemes
 * Responsive-table Js
 */

 
$(function() {
  $('.table-responsive').responsiveTable({
      addDisplayAllBtn: 'btn btn-secondary'
  });
});